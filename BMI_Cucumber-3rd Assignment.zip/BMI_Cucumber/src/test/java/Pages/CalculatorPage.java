package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CalculatorPage {

    WebDriver driver;
    WebDriverWait wait;
    public CalculatorPage(WebDriver driver1, WebDriverWait wait)
    {
        driver = driver1;
        this.wait = wait;

    }

    public void resetCalculator()
    {
        driver.findElement(By.className("clearbtn")).click();
    }
    public void enterAge(String a1)
    {
        driver.findElement(By.id("cage")).sendKeys(a1);
    }
    public void enterHeight(String b1)
    {
        driver.findElement(By.name("cheightmeter")).sendKeys(b1);
    }
    public void enterWeight(String c1)
    {
        driver.findElement(By.name("ckg")).sendKeys(c1);
    }
    public void clickCalculateBtn()
    {
        driver.findElement(By.xpath("//input[@type='image']")).click();

    }
    public String getResult()
    {
        String  actual;
        actual = driver.findElement(By.tagName("b")).getText().trim();
        return actual;
    }

    public String calculate1(String a1, String b1, String c1)
    {
        resetCalculator();
        enterAge(a1);
        enterHeight(b1);
        enterWeight(c1);
        clickCalculateBtn();
        String actual=getResult();
        return actual;


    }
}

